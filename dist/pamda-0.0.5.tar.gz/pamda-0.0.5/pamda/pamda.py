from pamda.pamda_class import pamda_class

pamda=pamda_class()
