from pamda.pamdata_class import pamdata_class
pamdata=pamdata_class()
